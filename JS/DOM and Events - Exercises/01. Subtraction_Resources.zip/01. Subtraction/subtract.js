function subtract() {
    console.log('TODO:...');
}
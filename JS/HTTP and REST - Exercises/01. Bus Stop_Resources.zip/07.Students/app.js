function attachEvents() {
  // TODO:
}

attachEvents();
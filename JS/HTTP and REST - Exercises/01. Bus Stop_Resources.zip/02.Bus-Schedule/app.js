function solve() {
    function depart() {
        // TODO: 
    }

    async function arrive() {
        // TODO:
    }

    return {
        depart,
        arrive
    };
}

let result = solve();